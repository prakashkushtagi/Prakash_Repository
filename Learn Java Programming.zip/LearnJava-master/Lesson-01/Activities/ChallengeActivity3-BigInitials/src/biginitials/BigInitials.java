/* Challenge Activity 3

Write a java program to print your initials in "large letters"

For example:

M     M  FFFFFF
M M M M  F
M  M  M  FFFF
M     M  F
M     M  F

 */

package biginitials;

/**
 *
 * @author mafudge
 */
public class BigInitials {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
}
