/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworld;

/**
 *
 * @author mafudge
 */
public class HelloWorld {

    /**
     * main() function executes when Java program is run.
     * 
     * public = accessible to all
     * static = does not need to be declared to be used
     * void = returns nothing
     */
    public static void main(String[] args) {
        // this is a comment, press [F6] to run me
        System.out.println("Hello, World!!!!!");
    }
}
