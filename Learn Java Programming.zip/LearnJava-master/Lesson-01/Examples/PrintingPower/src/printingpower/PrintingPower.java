/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package printingpower;

/**
 *
 * @author mafudge
 */
public class PrintingPower {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Let's print a huge smiley face!
        System.out.println("XXXXXXXXXXX");
        System.out.println("X  _   _  X");
        System.out.println("X  0   0  X");
        System.out.println("X    ^    X");
        System.out.println("X  \\___/  X"); // "\" is the escape character
        System.out.println("X         X");
        System.out.println("XXXXXXXXXXX");
        
    }
}
