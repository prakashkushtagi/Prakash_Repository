# Impor the argv method from the sys module
from sys import argv

# Assign the arguement variables to the variables 
# script, first, second, third
script, first, second, third = argv

# Display a string and the variable script
print "The script is called:", script
# Display a string and the variable first
print "Your first variable is:", first
# Display a string and the variable second
print "Your second variable is:", second
# Display a string and the variable third
print "Your third variable is:", third