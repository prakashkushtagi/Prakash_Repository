# Display the string "Mary had a little lamb"
print "mary had a little lamb"
# Display the formatted string "Its fleece was white as %s."
# after inserting the string 'snow'
print "Its fleece was white as %s." % 'snow'
# Display the string "And everywhere that Mary went."
print "And everywhere that Mary went."
# Display the string "." ten times on the same line
print "." * 10 # what'd that do?

end1 = "C" # Assign the string "C" to the variable end1
end2 = "h" # Assign the string "h" to the variable end2
end3 = "e" # Assign the string "e" to the variable end3
end4 = "e" # Assign the string "e" to the variable end4
end5 = "s" # Assign the string "s" to the variable end5
end6 = "e" # Assign the string "e" to the variable end6
end7 = "B" # Assign the string "B" to the variable end7
end8 = "u" # Assign the string "u" to the variable end8
end9 = "r" # Assign the string "r" to the variable end9
end10 = "g" # Assign the string "g" to the variable end10
end11 = "e" # Assign the string "e" to the variable end11
end12 = "r" # Assign the string "r" to the variable end12

# watch that comma at the end. try removing it to see what happens
# Concatenate the variables end1, end2, end3, end4, end5, and end6
# Concatenate the variables end7, end8, end9, end10, end11, and end12
# And Display them on the same line
print end1 + end2 + end3 + end4 + end5 + end6,
print end7 + end8 + end9 + end10 + end11 + end12