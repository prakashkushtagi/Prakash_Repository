# print the string "I will now count my chickens"
print "I will now count my chickens:"

# Calculate and print the number of hens 
print "Hens", 25.0 + 30.0 / 6.0
# Calculate and print the nubmer of roosters
print "Roosters", 100.0 - 25.0 * 3.0 % 4.0

# Print the string "Now I will count the eggs"
print "Now I will count the eggs:"

# Calculate and print the number of eggs
print 3.0 + 2.0 + 1.0 - 5.0 + 4.0 % 2.0 - 1.0 / 4.0 + 6.0

# Print a string
print "Is it true that 3 + 2 < 5 - 7?"

# Calculate and print the answer to 3 + 2 < 5 - 7
print 3.0 + 2.0 < 5.0 - 7.0

# Calculate and print the answer to 3 + 2
print "What is 3 + 2?", 3.0 + 2.0
# Calculate and print the answer to 5 - 7
print "What is 5 - 7?", 5.0 - 7.0

# Print the string "Oh, that's why it's False."
print "Oh, that's why it's False."

# Print the string "What about some more."
print "How about some more."

# Print the string "Is it greater?" and calculate and print 5 > -2
print "Is it greater?", 5.0 > -2.0
# Print the string "Is it greater or equal?" and calculate 5 >= -2
print "Is it greater or equal?", 5.0 >= -2.0
# Print the string "Is it less or equal?" and calculate 5 <= -2
print "Is it less or equal?", 5.0 <= -2.0