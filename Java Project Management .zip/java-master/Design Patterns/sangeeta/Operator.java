package com.sapient.usecase;

public interface Operator 
{

	public void open();
	
	public void read();
	
	public void write();
}
