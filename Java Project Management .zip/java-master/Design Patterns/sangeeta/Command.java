package com.sapient.usecase;

public interface Command {

	public void execute();
}
