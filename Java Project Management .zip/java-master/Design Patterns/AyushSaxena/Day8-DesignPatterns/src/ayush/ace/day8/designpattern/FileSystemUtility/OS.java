package ayush.ace.day8.designpattern.FileSystemUtility;

public interface OS {

	void open();
	void close();
	void write();
	
	
}
