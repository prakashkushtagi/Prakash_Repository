package ayush.ace.day8.designpattern.FileSystemUtility;

public interface Command {

	void execute();
}
