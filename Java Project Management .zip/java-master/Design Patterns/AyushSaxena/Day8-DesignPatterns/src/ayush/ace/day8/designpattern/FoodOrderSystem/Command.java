package ayush.ace.day8.designpattern.FoodOrderSystem;


//Command
public interface Command {

	public void execute();
	
}
