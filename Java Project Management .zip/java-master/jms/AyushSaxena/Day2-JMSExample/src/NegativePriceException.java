
public class NegativePriceException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	NegativePriceException(String message){
		
		super(message);
	
	}
	
	
}
