package com.sapient.ace.jms;

public class InvalidOrderException extends Exception {
	
	

}
