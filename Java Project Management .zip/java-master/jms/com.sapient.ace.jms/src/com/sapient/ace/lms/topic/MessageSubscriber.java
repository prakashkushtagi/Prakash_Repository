package com.sapient.ace.lms.topic;

public class MessageSubscriber {

}
