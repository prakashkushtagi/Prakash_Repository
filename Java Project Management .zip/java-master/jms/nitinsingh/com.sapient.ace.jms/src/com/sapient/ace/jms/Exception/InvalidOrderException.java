package com.sapient.ace.jms.Exception;

public class InvalidOrderException extends Exception {
	
	

}
