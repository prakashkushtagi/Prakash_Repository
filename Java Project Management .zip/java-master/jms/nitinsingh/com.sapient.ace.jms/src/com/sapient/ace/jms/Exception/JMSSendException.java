package com.sapient.ace.jms.Exception;

public class JMSSendException extends Exception{
	
	

}
