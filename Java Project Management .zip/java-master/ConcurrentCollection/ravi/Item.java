package com.examples.producerconsumer;

public interface Item 
{
  int getValue();
}
