Producer Consumer Problems Solution by following strategy:
  1. Producer Consumer using LinkedBlockingQueue
  2. Producer Consumer using ArrayBlockingQueue
  3. Producer Consumer using LinkedTransferQueue
  4. Producer Consumer using LinkedBlockingDequeue
